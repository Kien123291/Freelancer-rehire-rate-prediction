# Data 200: Data Systems for Data Analytics


# Name:Kien Nguyen


### **Task**: Scrape data from Goodreads.com 📚

---

### **Objective**
you will scrape and analyze data from Goodreads.com. The work is split into two parts, each focusing on different aspects of the data
1. **"Best Books" Analysis**: Explore Goodreads' "Best Books" lists for a specific year.
2. **Author-Level Analysis**: Study the trends and patterns in the works of a specific author.

---

### **Instructions**

#### **Task 1: Best Books**
You are tasked with analyzing Goodreads' "Best Books" lists for a specific year:

[Best Books of 2021](https://www.goodreads.com/list/best_of_year/2021) 




**Tasks**:
1. Scrape data from the Goodreads "Best Books of [Year]" list:

2. Collect the following data for each book:
   - Title
   - Publication date (first published)
   - Author
   - Genre (if available, and feel free to pick the first genre listed)
   - Average rating
   - Number of ratings
   - Number of pages
   - Rank
   - Language (if available)
   - Number of people who are currently reading (if available)
   - Number of people who want to read (if available)
3. Perform the following analyses:
   - **Genre ratings**:
       - Compare average ratings across genres. Which 2-3 genres tends to have the highest ratings? Create a table showing average rating score, and average rank by genre.
   - **Popularity and ratings**:
       - Examine whether books with more ratings tend to have higher or lower average scores. Create a scatterplot showing the relationship between the number of ratings and average rating. On the x-axis, you should have **number of ratings**; on the y-axis, you should have **average rating**.

---

#### **Task 2: Author-Level Analysis**
analyzing books by a specific author:


Ernest Hemingway    | [Ernest Hemingway](https://www.goodreads.com/author/list/1455)     | Jul 21, 1899   |


**Tasks**:
1. Scrape all books by your assigned author:
   - Use the link provided for your author.
2. Collect the following data for each book:
   - Title
   - Publication date (first published)
   - Author
   - Genre (if available, and feel free to pick the first genre listed)
   - Average rating
   - Number of ratings
   - Number of pages
   - Rank (from the books written by the author)
   - Language (if available)
   - Number of people who are currently reading (if available)
   - Number of people who want to read (if available)
3. Performing the following analyses:
   - **Language Distribution**:
     - How many books has the author published in English? In other languages? Create a table showing the count of books by language.
   - **Author's Age and Page Count**:
     - Do authors tend to write longer books as they age? Use the author's birthday to calculate their age at the time of each book's publication. Create a line plot with **author's age** on the x-axis and **page count** on the y-axis.
   - **Author's Age and Rating**:
     - For English-only books, create a line plot with **author's age** on the x-axis and **average rating** on the y-axis.
     - Repeat the analysis including books in languages other than English. Does your interpretation change?
   - **Pages vs. Ratings**:
     - Is there a relationship between the number of pages and a book's average rating? Create a scatterplot with **page count** on the x-axis and **average rating** on the y-axis.
   - **Interest on a book**:
     - Is there a relationship between the number of people who are currently reading the book and the number of people who left a rating? Create a scatterplot with **number of people who are currently reading** on the x-axis and **number of ratings** on the y-axis. Create a second scatterplot with **average rating** on the y-axis. Do books with more interest tend to receive higher ratings?

---




### **Tips**
- Make sure to insert time.sleep() right after you request driver to go to a link (before requesting elements). Make sure to wait at least 0.7 second, or even slightly higher if you run into issues.
- Try-except blocks will be your friend because xpath positions on a page may differ depending on the book and content availability.

---

### **Resources**
- Selenium documentation: https://www.selenium.dev/documentation/
- Pandas documentation: https://pandas.pydata.org/docs/
- Matplotlib documentation: https://matplotlib.org/stable/contents.html




```python
pip install -r requirements.txt
```

    Requirement already satisfied: selenium==4.27.1 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from -r requirements.txt (line 1)) (4.27.1)
    Requirement already satisfied: webdriver-manager==4.0.2 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from -r requirements.txt (line 2)) (4.0.2)
    Requirement already satisfied: pandas==2.2.3 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from -r requirements.txt (line 3)) (2.2.3)
    Requirement already satisfied: matplotlib==3.10.0 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from -r requirements.txt (line 4)) (3.10.0)
    Requirement already satisfied: seaborn==0.13.2 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from -r requirements.txt (line 5)) (0.13.2)
    Requirement already satisfied: urllib3<3,>=1.26 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from urllib3[socks]<3,>=1.26->selenium==4.27.1->-r requirements.txt (line 1)) (2.2.3)
    Requirement already satisfied: trio~=0.17 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from selenium==4.27.1->-r requirements.txt (line 1)) (0.27.0)
    Requirement already satisfied: trio-websocket~=0.9 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from selenium==4.27.1->-r requirements.txt (line 1)) (0.11.1)
    Requirement already satisfied: certifi>=2021.10.8 in /opt/homebrew/opt/certifi/lib/python3.13/site-packages (from selenium==4.27.1->-r requirements.txt (line 1)) (2024.12.14)
    Requirement already satisfied: typing_extensions~=4.9 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from selenium==4.27.1->-r requirements.txt (line 1)) (4.12.2)
    Requirement already satisfied: websocket-client~=1.8 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from selenium==4.27.1->-r requirements.txt (line 1)) (1.8.0)
    Requirement already satisfied: requests in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from webdriver-manager==4.0.2->-r requirements.txt (line 2)) (2.32.3)
    Requirement already satisfied: python-dotenv in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from webdriver-manager==4.0.2->-r requirements.txt (line 2)) (1.0.1)
    Requirement already satisfied: packaging in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from webdriver-manager==4.0.2->-r requirements.txt (line 2)) (24.2)
    Requirement already satisfied: numpy>=1.26.0 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from pandas==2.2.3->-r requirements.txt (line 3)) (2.2.0)
    Requirement already satisfied: python-dateutil>=2.8.2 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from pandas==2.2.3->-r requirements.txt (line 3)) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from pandas==2.2.3->-r requirements.txt (line 3)) (2024.2)
    Requirement already satisfied: tzdata>=2022.7 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from pandas==2.2.3->-r requirements.txt (line 3)) (2024.2)
    Requirement already satisfied: contourpy>=1.0.1 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from matplotlib==3.10.0->-r requirements.txt (line 4)) (1.3.1)
    Requirement already satisfied: cycler>=0.10 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from matplotlib==3.10.0->-r requirements.txt (line 4)) (0.12.1)
    Requirement already satisfied: fonttools>=4.22.0 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from matplotlib==3.10.0->-r requirements.txt (line 4)) (4.55.3)
    Requirement already satisfied: kiwisolver>=1.3.1 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from matplotlib==3.10.0->-r requirements.txt (line 4)) (1.4.7)
    Requirement already satisfied: pillow>=8 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from matplotlib==3.10.0->-r requirements.txt (line 4)) (11.0.0)
    Requirement already satisfied: pyparsing>=2.3.1 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from matplotlib==3.10.0->-r requirements.txt (line 4)) (3.2.0)
    Requirement already satisfied: six>=1.5 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from python-dateutil>=2.8.2->pandas==2.2.3->-r requirements.txt (line 3)) (1.17.0)
    Requirement already satisfied: attrs>=23.2.0 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from trio~=0.17->selenium==4.27.1->-r requirements.txt (line 1)) (24.2.0)
    Requirement already satisfied: sortedcontainers in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from trio~=0.17->selenium==4.27.1->-r requirements.txt (line 1)) (2.4.0)
    Requirement already satisfied: idna in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from trio~=0.17->selenium==4.27.1->-r requirements.txt (line 1)) (3.10)
    Requirement already satisfied: outcome in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from trio~=0.17->selenium==4.27.1->-r requirements.txt (line 1)) (1.3.0.post0)
    Requirement already satisfied: sniffio>=1.3.0 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from trio~=0.17->selenium==4.27.1->-r requirements.txt (line 1)) (1.3.1)
    Requirement already satisfied: wsproto>=0.14 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from trio-websocket~=0.9->selenium==4.27.1->-r requirements.txt (line 1)) (1.2.0)
    Requirement already satisfied: pysocks!=1.5.7,<2.0,>=1.5.6 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from urllib3[socks]<3,>=1.26->selenium==4.27.1->-r requirements.txt (line 1)) (1.7.1)
    Requirement already satisfied: charset_normalizer<4,>=2 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from requests->webdriver-manager==4.0.2->-r requirements.txt (line 2)) (3.4.0)
    Requirement already satisfied: h11<1,>=0.9.0 in /opt/homebrew/Cellar/jupyterlab/4.3.3/libexec/lib/python3.13/site-packages (from wsproto>=0.14->trio-websocket~=0.9->selenium==4.27.1->-r requirements.txt (line 1)) (0.14.0)
    Note: you may need to restart the kernel to use updated packages.



```python
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
import time
import re
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
```

## Task 1: Top Books Analysis 

The goal of this task is to extract book data from **Goodreads' "Best Books" lists for 2021** and use it to analyze the **relationship between genres and ratings** as well as **the connection between popularity (ranking) and ratings**. Explanations and clarifications of the code will be provided through comments, while descriptive analysis and insights will be presented in separate Jupyter Notebook cells.


```python
## Initialize an instance of the Selenium driver with ChromeDriverManager
chrome_options = Options()
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
```


```python
def scrape_book_url(url, ranks):
    """
    Scrapes book data from a given Goodreads book URL using Selenium and returns the extracted information.
    
    Parameters:
        url (str): The URL of the Goodreads book page to scrape.
        ranks (dict): A dictionary mapping URLs to their ranking.

    Returns:
        list: A list containing the book's rank, title, author, published date, genre, average rating, 
              number of ratings, number of pages, number of people currently reading, number of people wanting to read, and language.
    """
    try:
        # Navigate to the specified URL
        driver.get(url)
        time.sleep(1)

        # Close overlay popup if it exists
        overlay = driver.find_elements(By.CLASS_NAME, "Overlay__close")
        if len(overlay) > 0:
            try:
                close_overlay_button = overlay[0].find_element(By.TAG_NAME, "button")
                close_overlay_button.click()
                time.sleep(0.5)
            except Exception:
                pass

        # Extract the book's title
        title = safe_extract_text(lambda: driver.find_element(By.TAG_NAME, "h1").text)
        
        # Extract the author's name
        author = safe_extract_text(lambda: driver.find_element(By.XPATH, '//*[@data-testid="name"]').text)

        # Extract and parse the published date
        published_date_text = safe_extract_text(lambda: driver.find_element(By.XPATH, '//*[@data-testid="publicationInfo"]').text)
        published_date = safe_extract_text(lambda: re.search(r"(\w+\s\d{1,2},\s\d{4})", published_date_text).group(0))

        # Extract the main genre of the book
        main_genre = safe_extract_text(lambda: driver.find_element(By.CLASS_NAME, "BookPageMetadataSection__genreButton").text)

        # Extract the average rating of the book
        avg_rating = safe_extract_text(lambda: float(driver.find_element(By.CLASS_NAME, "RatingStatistics__rating").text))

        # Extract and parse the number of ratings
        num_ratings_text = safe_extract_text(lambda: driver.find_element(By.XPATH, '//*[@data-testid="ratingsCount"]').text)
        num_ratings = safe_extract_text(lambda: int(num_ratings_text.split(" ")[0].replace(",", "")))

        # Extract and parse the number of pages
        pages_text = safe_extract_text(lambda: driver.find_element(By.XPATH, '//*[@data-testid="pagesFormat"]').text)
        pages = safe_extract_text(lambda: int(pages_text.split(" ")[0]))

        # Extract the number of people currently reading the book
        people_readings_text = safe_extract_text(lambda: parse_large_num(driver.find_element(By.XPATH, '//*[@data-testid="currentlyReadingSignal"]').text.split(" ")[0]))

        # Extract the number of people wanting to read the book
        people_want_to_read_text = safe_extract_text(lambda: parse_large_num(driver.find_element(By.XPATH, '//*[@data-testid="toReadSignal"]').text.split(" ")[0]))

        # Open the "Book details and editions" section if available
        book_details_button = driver.find_elements(By.XPATH, '//*[@aria-label="Book details and editions"]')
        if book_details_button:
            driver.execute_script("arguments[0].click();", book_details_button[0])

        # Extract the language of the book from the details section
        last_desc_list = safe_extract_text(lambda: driver.find_elements(By.CLASS_NAME, "DescListItem")[-1])

        if last_desc_list is not None and "Language" in last_desc_list.text:
            language = safe_extract_text(lambda: last_desc_list.find_element(By.XPATH, './/*[@data-testid="contentContainer"]').text)
        else:
            language = None

        # Return the extracted data as a list
        return [ranks[url], title, author, published_date, main_genre, avg_rating, num_ratings, pages, people_readings_text, people_want_to_read_text, language]
        
    except Exception as e:
        print(f"Error scraping {url}: {e}")

def safe_extract_text(func, default=None):
    """
    Safely executes a function and extracts its returned value. If an exception occurs, 
    returns a default value instead.

    Parameters:
        func (callable): A function to be executed, typically used to retrieve text.
        default (any, optional): The default value to return if an exception occurs. Defaults to None.

    Returns:
        any: The result of the function execution, or the default value in case of an exception.
    """
    try:
        return func()
    except Exception:
        return default

def parse_large_num(text):
    """
    Parses a text representation of large numbers (e.g., "1.2k", "3.5m", or "1,200") into a 
    numerical value in thousands (k).

    Parameters:
        text (str): The string representation of the number to be parsed.

    Returns:
        float or None: The parsed number in thousands (k), or None if parsing fails.
    """
    try:
        if ("k" in text):
            return round(float(text.replace("k", "")), 2)
        if ("m" in text):
            return round(float(text.replace("m", ""))*1000, 2)
        if ("," in text):
            return round(float(text.replace(",", ""))/1000, 2)
        return round(float(text)/1000, 2)

    except Exception:
        return None

def print_progress_bar(current, total, bar_length=100):
    """
    Prints a progress bar in the console, replacing the current line.
    
    Parameters:
        current (int): The current progress (e.g., current iteration).
        total (int): The total value (e.g., total iterations).
        bar_length (int): The length of the progress bar in characters.
    """
    progress = current / total
    completed_length = int(bar_length * progress)
    bar = "=" * completed_length + "-" * (bar_length - completed_length)
    percentage = int(progress * 100)
    print(f"Progress: [{bar}] {percentage}% - {current} scraped out of {total}", end="\r")
```

### Getting all books URLs to scrape their details
The requirement is to scrape the details of all books in the 2021 Best Books; however, there are many book information and data points, such as the genres, number of pages, languages, etc. that cannot be retrieved only through the pages of the list. Therefore, we first need to scrape all of the books' URLs, and then go to each and every URLs to scrape their inner details.


```python
starting_time = time.time()

urls_2021 = []
ranks_2021 = {}

def scrape_best_books_2021(total_pages):
    """
    Scrapes book URLs and their ranks from Goodreads' "Best Books of 2021" lists across multiple pages.
    
    Parameters:
        total_pages (int): The total number of pages to scrape (e.g., 14 pages for this dataset).
    """
    for i in range(1, total_pages+1):
        driver.get(f"https://www.goodreads.com/list/best_of_year/2021?id=157516.Best_Books_of_2021&page={i}")
        print(f"Scraping page {i} out of {total_pages} pages")
        time.sleep(0.7)

        # Close modal overlay pop-up if it exists
        overlay = driver.find_elements(By.CLASS_NAME, "modal--centered")
        if len(overlay) > 0:
            try:
                close_overlay_button = overlay[0].find_element(By.TAG_NAME, "button")
                close_overlay_button.click()
                time.sleep(3)
            except Exception:
                pass
        # Locate the main table containing the list of books
        mainBody = driver.find_element(By.ID, "all_votes")
        rows = mainBody.find_elements(By.TAG_NAME, "tr")

        # Loop through each row to extract book's rank and URL
        for row in rows:
            rank = int(row.find_element(By.CLASS_NAME, "number").text)
            url = row.find_element(By.CLASS_NAME, "bookTitle").get_attribute("href")
            
            urls_2021.append(url)
            ranks_2021[url] = rank

scrape_best_books_2021(14)
print(f"Number of books' URL to scrape: {len(urls_2021)}")
```

    Scraping page 1 out of 14 pages
    Scraping page 2 out of 14 pages
    Scraping page 3 out of 14 pages
    Scraping page 4 out of 14 pages
    Scraping page 5 out of 14 pages
    Scraping page 6 out of 14 pages
    Scraping page 7 out of 14 pages
    Scraping page 8 out of 14 pages
    Scraping page 9 out of 14 pages
    Scraping page 10 out of 14 pages
    Scraping page 11 out of 14 pages
    Scraping page 12 out of 14 pages
    Scraping page 13 out of 14 pages
    Scraping page 14 out of 14 pages
    Number of books' URL to scrape: 1396


### Scrape for single book's detail
As it was depicted, the number of books to scrape is 1396, therefore the process of scraping for each book's details is gonna take a lot of computational time (roughly 2 hours based on the different machine). It should be noted also that due to the big amount of requests to the Goodreads server, some links may return a 502 Bad Gateway error. The code has been optimized so that the process will not break down in those situations, but the books whose URL requests are met with such errors will be filtered out later on in the data analysis part.


```python
print("This is a long process, since we have to scrape all the individual book's URL.\nPlease wait patiently, or lower the number of pages scraped.")

books_2021 = []

for i, url in enumerate(urls_2021):
    book_data = scrape_book_url(url, ranks_2021)
    books_2021.append(book_data)
    print_progress_bar(i+1, len(urls_2021))

print("\nDone!")
```

    This is a long process, since we have to scrape all the individual book's URL.
    Please wait patiently, or lower the number of pages scraped.
    Progress: [====================================================================================================] 100% - 1396 scraped out of 1396
    Done!


### Inspect and prepare data for further data analysis

Through inspection, we can see that this dataset contains information about 1,396 books, with details related to their rank, title, author, genre, etc.. The dataset has 11 columns, with the following key details:

- **rank**: An integer value indicating the rank of the book (non-null for all entries).
- **title**: The title of the book (non-null for all entries).
- **author**: The author of the book (7 missing values).
- **published_date**: The publication date of the book (7 missing values).
- **main_genre**: The primary genre of the book (36 missing values).
- **avg_rating**: The average rating of the book on a scale (7 missing values, floating-point).
- **num_ratings**: The number of ratings the book has received (7 missing values, floating-point).
- **pages**: The number of pages in the book (29 missing values, floating-point).
- **people_readings_(thousand)**: The number of people who have read the book, measured in thousands (21 missing values).
- **people_want_to_read(thousands)**: The number of people who want to read the book, measured in thousands (11 missing values).
- **language**: The language of the book (21 missing values).


```python
# Create a Pandas DataFrame for all the books' data
df_2021 = pd.DataFrame(books_2021, columns=['rank', 'title', 'author', 'published_date', 'main_genre', 'avg_rating', 'num_ratings', 
                                  'pages', 'people_readings_(thousands)', 'people_want_to_read_(thousands)', 'language'])

df_2021
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rank</th>
      <th>title</th>
      <th>author</th>
      <th>published_date</th>
      <th>main_genre</th>
      <th>avg_rating</th>
      <th>num_ratings</th>
      <th>pages</th>
      <th>people_readings_(thousands)</th>
      <th>people_want_to_read_(thousands)</th>
      <th>language</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Project Hail Mary</td>
      <td>Andy Weir</td>
      <td>May 4, 2021</td>
      <td>Science Fiction</td>
      <td>4.50</td>
      <td>688658.0</td>
      <td>476.0</td>
      <td>44.20</td>
      <td>662.00</td>
      <td>English</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>The Four Winds</td>
      <td>Kristin Hannah</td>
      <td>February 2, 2021</td>
      <td>Historical Fiction</td>
      <td>4.30</td>
      <td>778170.0</td>
      <td>464.0</td>
      <td>48.20</td>
      <td>516.00</td>
      <td>English</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Malibu Rising</td>
      <td>Taylor Jenkins Reid</td>
      <td>May 27, 2021</td>
      <td>Fiction</td>
      <td>4.03</td>
      <td>1137131.0</td>
      <td>369.0</td>
      <td>41.50</td>
      <td>938.00</td>
      <td>English</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>A Court of Silver Flames</td>
      <td>Sarah J. Maas</td>
      <td>February 16, 2021</td>
      <td>Fantasy</td>
      <td>4.47</td>
      <td>1537340.0</td>
      <td>757.0</td>
      <td>87.40</td>
      <td>707.00</td>
      <td>English</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>The Love Hypothesis</td>
      <td>Ali Hazelwood</td>
      <td>September 14, 2021</td>
      <td>Contemporary</td>
      <td>4.13</td>
      <td>1543673.0</td>
      <td>373.0</td>
      <td>39.90</td>
      <td>1000.00</td>
      <td>English</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1391</th>
      <td>1392</td>
      <td>Katharine Parr, the Sixth Wife</td>
      <td>Alison Weir</td>
      <td>May 13, 2021</td>
      <td>Historical Fiction</td>
      <td>4.23</td>
      <td>5342.0</td>
      <td>544.0</td>
      <td>0.43</td>
      <td>13.00</td>
      <td>English</td>
    </tr>
    <tr>
      <th>1392</th>
      <td>1392</td>
      <td>Wicked Empire</td>
      <td>Tracy Lorraine</td>
      <td>December 16, 2021</td>
      <td>Dark</td>
      <td>4.34</td>
      <td>4580.0</td>
      <td>336.0</td>
      <td>1.22</td>
      <td>2.27</td>
      <td>English</td>
    </tr>
    <tr>
      <th>1393</th>
      <td>1394</td>
      <td>Paradise Lagoon</td>
      <td>Caroline Peckham</td>
      <td>October 18, 2021</td>
      <td>Reverse Harem</td>
      <td>4.44</td>
      <td>10655.0</td>
      <td>632.0</td>
      <td>1.33</td>
      <td>4.72</td>
      <td>English</td>
    </tr>
    <tr>
      <th>1394</th>
      <td>1395</td>
      <td>Carnival Hill</td>
      <td>Caroline Peckham</td>
      <td>June 23, 2021</td>
      <td>Reverse Harem</td>
      <td>4.41</td>
      <td>12267.0</td>
      <td>449.0</td>
      <td>1.18</td>
      <td>5.05</td>
      <td>English</td>
    </tr>
    <tr>
      <th>1395</th>
      <td>1396</td>
      <td>Warrior Fae</td>
      <td>Caroline Peckham</td>
      <td>April 30, 2021</td>
      <td>Fantasy</td>
      <td>4.41</td>
      <td>37423.0</td>
      <td>680.0</td>
      <td>4.43</td>
      <td>23.20</td>
      <td>English</td>
    </tr>
  </tbody>
</table>
<p>1396 rows × 11 columns</p>
</div>




```python
## Inspect data information to detect invalid/NoneType data
df_2021.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1396 entries, 0 to 1395
    Data columns (total 11 columns):
     #   Column                           Non-Null Count  Dtype  
    ---  ------                           --------------  -----  
     0   rank                             1396 non-null   int64  
     1   title                            1396 non-null   object 
     2   author                           1389 non-null   object 
     3   published_date                   1389 non-null   object 
     4   main_genre                       1360 non-null   object 
     5   avg_rating                       1389 non-null   float64
     6   num_ratings                      1389 non-null   float64
     7   pages                            1367 non-null   float64
     8   people_readings_(thousands)      1375 non-null   float64
     9   people_want_to_read_(thousands)  1385 non-null   float64
     10  language                         1375 non-null   object 
    dtypes: float64(5), int64(1), object(5)
    memory usage: 120.1+ KB



```python
## Inspect numerical data points
df_2021.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rank</th>
      <th>avg_rating</th>
      <th>num_ratings</th>
      <th>pages</th>
      <th>people_readings_(thousands)</th>
      <th>people_want_to_read_(thousands)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1396.000000</td>
      <td>1389.000000</td>
      <td>1.389000e+03</td>
      <td>1367.000000</td>
      <td>1375.000000</td>
      <td>1385.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>692.262178</td>
      <td>4.006040</td>
      <td>3.628990e+04</td>
      <td>336.036576</td>
      <td>2.523622</td>
      <td>44.043451</td>
    </tr>
    <tr>
      <th>std</th>
      <td>401.772005</td>
      <td>0.319559</td>
      <td>1.160404e+05</td>
      <td>124.704060</td>
      <td>6.665520</td>
      <td>98.811182</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>2.000000</td>
      <td>2.000000e+00</td>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>349.000000</td>
      <td>3.800000</td>
      <td>1.742000e+03</td>
      <td>272.000000</td>
      <td>0.160000</td>
      <td>2.620000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>666.000000</td>
      <td>4.030000</td>
      <td>5.935000e+03</td>
      <td>336.000000</td>
      <td>0.560000</td>
      <td>9.890000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>1039.000000</td>
      <td>4.230000</td>
      <td>2.297000e+04</td>
      <td>391.000000</td>
      <td>1.950000</td>
      <td>36.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1396.000000</td>
      <td>5.000000</td>
      <td>1.543673e+06</td>
      <td>1120.000000</td>
      <td>98.500000</td>
      <td>1000.000000</td>
    </tr>
  </tbody>
</table>
</div>



After inspection, we can deduce that the dataset contains some missing data that can affect the further calculation and analysis. The missing data can be due to the fact that the individual book's page on Goodreads does not contain the required information, or the process of scraping data meets with some network errors. 

To clean the data, we will drop all the null results from the four columns: **authors, main_genre, avg_rating, num_ratings**, since our analysis is based heavily on the genres as well as the ratings data, while the books without a respective author do indicate an invalid book as it makes little sense for a book without a writer.

After cleaning the data and drop the rows which contain the null results, our clean dataset now consists of 1360 books, as depicted below. The cleaned data is saved to `best_books_2021.csv`


```python
# Drop invalid rows
cleaned_df_2021 = df_2021.dropna(subset=['author', 'main_genre', 'avg_rating', 'num_ratings'])

# Convert the column to datetime
cleaned_df_2021.loc[:, 'published_date'] = pd.to_datetime(cleaned_df_2021['published_date'], errors='coerce')

# Ensure the column has datetime values and then extract the date part
cleaned_df_2021.loc[:, 'published_date'] = cleaned_df_2021['published_date'].apply(lambda x: x.date() if pd.notna(x) else x)

cleaned_df_2021.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Index: 1360 entries, 0 to 1395
    Data columns (total 11 columns):
     #   Column                           Non-Null Count  Dtype  
    ---  ------                           --------------  -----  
     0   rank                             1360 non-null   int64  
     1   title                            1360 non-null   object 
     2   author                           1360 non-null   object 
     3   published_date                   1360 non-null   object 
     4   main_genre                       1360 non-null   object 
     5   avg_rating                       1360 non-null   float64
     6   num_ratings                      1360 non-null   float64
     7   pages                            1339 non-null   float64
     8   people_readings_(thousands)      1359 non-null   float64
     9   people_want_to_read_(thousands)  1359 non-null   float64
     10  language                         1347 non-null   object 
    dtypes: float64(5), int64(1), object(5)
    memory usage: 127.5+ KB



```python
# Write cleaned data to csv file
cleaned_df_2021.to_csv('best_books_2021.csv', index=False, encoding='utf-8')
```

### Genre ratings analysis
Our target here is to compare average ratings and average popularity rank across genres. We are going to group the `genre` data with the `avg_rating` and the `rank` data, and create respective tables to determine their relationship. 


```python
# Group genre with average ratings and popularity ranking, and create the respective tables with sorted data to demonstrate the relationship
genre_avg_rating_2021 = cleaned_df_2021.groupby('main_genre').agg(
    avg_rating=('avg_rating', 'mean'),
).reset_index()

genre_rank_2021 = cleaned_df_2021.groupby('main_genre').agg(
    rank=('rank', 'mean'),
).reset_index()

genre_avg_rating_2021 = genre_avg_rating_2021.sort_values(by='avg_rating', ascending=False)
genre_rank_2021 = genre_rank_2021.sort_values(by='rank', ascending=True)
```


```python
genre_avg_rating_2021
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>main_genre</th>
      <th>avg_rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>4</th>
      <td>Biblical Fiction</td>
      <td>4.7000</td>
    </tr>
    <tr>
      <th>40</th>
      <td>Manga</td>
      <td>4.6150</td>
    </tr>
    <tr>
      <th>51</th>
      <td>Parenting</td>
      <td>4.6100</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Christian</td>
      <td>4.4825</td>
    </tr>
    <tr>
      <th>60</th>
      <td>Romantic Suspense</td>
      <td>4.4800</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>36</th>
      <td>LGBT</td>
      <td>3.6360</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Comics</td>
      <td>3.6100</td>
    </tr>
    <tr>
      <th>47</th>
      <td>Novella</td>
      <td>3.6000</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Dystopia</td>
      <td>3.5800</td>
    </tr>
    <tr>
      <th>56</th>
      <td>Queer</td>
      <td>3.5400</td>
    </tr>
  </tbody>
</table>
<p>74 rows × 2 columns</p>
</div>




```python
genre_rank_2021
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>main_genre</th>
      <th>rank</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>64</th>
      <td>Spirituality</td>
      <td>15.0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Dystopia</td>
      <td>99.0</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Adhd</td>
      <td>163.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Biblical Fiction</td>
      <td>191.0</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Fantasy Romance</td>
      <td>193.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Economics</td>
      <td>1225.0</td>
    </tr>
    <tr>
      <th>65</th>
      <td>Sports Romance</td>
      <td>1274.0</td>
    </tr>
    <tr>
      <th>50</th>
      <td>Paranormal Romance</td>
      <td>1318.0</td>
    </tr>
    <tr>
      <th>47</th>
      <td>Novella</td>
      <td>1337.0</td>
    </tr>
    <tr>
      <th>60</th>
      <td>Romantic Suspense</td>
      <td>1375.0</td>
    </tr>
  </tbody>
</table>
<p>74 rows × 2 columns</p>
</div>



The two tables provided give insight into the average ratings and popularity rankings of various book genres. The first table shows the average ratings (out of 5) for each genre, while the second table presents their popularity ranks, with a lower rank indicating greater popularity.

The first table highlights the average ratings for a range of genres. Among the genres listed, Biblical Fiction received the highest average rating of 4.7, indicating that it is the most positively regarded genre. Following closely are Manga and Parenting, with average ratings of 4.615 and 4.61, respectively. At the other end of the spectrum, Queer received the lowest rating of 3.54, followed by Dystopia (3.58) and Novella (3.6). These genres seem to have received more mixed or less favorable feedback from readers, as the topics described in the books may receive a diversity of opinion.

In terms of popularity, the second table ranks genres based on their popularity, where a lower rank represents higher popularity. Spirituality ranks 1st, making it the most popular genre, followed by Dystopia at 2nd, and Adhd at 3rd. On the other hand, genres such as Sports Romance (1274th), Paranormal Romance (1318th), and Novella (1337th) rank among the least popular, with significantly higher rank numbers.

A comparison between the two tables reveals several interesting trends. For instance, Biblical Fiction stands out not only as the highest-rated genre with an impressive rating of 4.7 but also maintains a relatively high popularity rank of 191st, suggesting that it is both highly regarded and also popular among Goodreads reader. In contrast, although Romantic Suspense achieves a top-5 rating, it performs poorly in terms of popularity, ranking at the bottom of the respective table. This could suggest that the dataset contains few books from this genre, and the high rating might be driven by a few standout books, rather than a widespread preference for the genre. Dystopia sees an opposite trend, with it ranking low on the ratings but are very popular among readers, which can be understood looking into the current world's situation.

It should be noted that, the genre in this dataset is the **main genre**, meaning that it is the first one listed on the book's web page, and a book can has many genres which can lead to a different interpretation. 









### Popularity and ratings analysis
Our target here is to compare popularity and ratings and determine their relationships. First, we need to inspect the data for the two columns `avg_rating` and `num_ratings`, to see if they contain outliers. If they do, we are going to drop all the instances of outliers, and work with the non-outlier dataset.


```python
fig, axes = plt.subplots(1, 2, figsize=(15, 6), sharey=True)

# First boxplot
sns.boxplot(x=cleaned_df_2021['avg_rating'], ax=axes[0])
axes[0].set_title('Boxplot of Average Ratings')
axes[0].set_xlabel('Average Ratings')

# Second boxplot
sns.boxplot(x=cleaned_df_2021['num_ratings'], ax=axes[1])
axes[1].set_title('Boxplot of Number of Ratings')
axes[1].set_xlabel('Number of Ratings')

plt.tight_layout()
plt.show()
```


    
![png](output_25_0.png)
    



```python
def drop_outliers(df, columns):
    """
    Drop outliers of given columns
    
    Parameters:
        df (pandas.DataFrame): DataFrame of the cleaned data
        columns (list): List of columns to be cleaned of outliers

    Returns:
        pandas.DataFrame: Cleaned DataFrame without outliers
    """
    for column in columns:
        # Compute Q1 (25th percentile) and Q3 (75th percentile)
        Q1 = df[column].quantile(0.25)
        Q3 = df[column].quantile(0.75)
        IQR = Q3 - Q1  # Interquartile Range
        
        # Define lower and upper bounds for outliers
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        
        df = df[(df[column] >= lower_bound) & (df[column] <= upper_bound)]

    return df
```


```python
df_2021_drop_outliers = drop_outliers(cleaned_df_2021, ['avg_rating', 'num_ratings'])
```


```python
print(f"Original data size: {cleaned_df_2021.shape[0]}")
print(f"Data size after outlier removal: {df_2021_drop_outliers.shape[0]}")
```

    Original data size: 1360
    Data size after outlier removal: 1170



```python
plt.figure(figsize=(10, 6))
sns.regplot(
    x='num_ratings', 
    y='avg_rating', 
    data=df_2021_drop_outliers, 
    scatter_kws={'alpha': 0.5, 'color': 'blue'}, 
    line_kws={'color': 'red'}
)

# Add labels and title
plt.xlabel('Number of Ratings')
plt.ylabel('Average Rating')
plt.title('Relationship Between Number of Ratings and Average Rating (Without Outliers)')
plt.grid(True)

# Show plot
plt.show()
```


    
![png](output_29_0.png)
    


The scatterplot examines the relationship between the number of ratings a book receives and its average rating. The x-axis represents the number of ratings, while the y-axis indicates the average rating. 

A dense cluster of points is visible on the left side of the graph, where the number of ratings is relatively low (close to 0-10,000). Within this range, the average ratings vary widely, spanning from approximately 3.2 to 4.6, though the majority of books tend to hover around a 4.0 rating.

As the number of ratings increases, the points become more sparse, and a slight downward trend emerges. This trend is reinforced by the red regression line, which shows a subtle negative slope. The line suggests that books with a higher number of ratings tend to have slightly lower average ratings, although the relationship is weak. Notably, even books with tens of thousands of ratings still display considerable variation in their scores, ranging from around 3.4 to above 4.2.

While books with fewer ratings exhibit more variability in their average scores, books with a greater number of ratings tend to stabilize around a slightly lower rating, with a modest downward trend in averages as the number of ratings grows.

## Task 2: Author-Level Analysis

The goal of this task is to extract book data from Ernest Hemingway's catalogue on Goodreads and use it to analyze the following details:
- Distribution of languages for published books
- Relationship between author's age and average page written
- Relationship between author's age and average rating
- Relationship between average rating and number of pages
- The current interests in the book

Explanations and clarifications of the code will, as mentioned, be provided through comments, while descriptive analysis and insights will be presented in separate Jupyter Notebook cells.

### Getting all book's URL to scrape the data

Similarly to the previous task, this task we also aim to scrape all the books' URLs, and use the retrieved ones to scrape the inner details. However, after inspecting the data provided by Goodreads, it is evidently that a lot of the books in the catalogue are invalid and of little usages for analyzing the aforementioned details. Therefore, to reduce the number of URLs need to be scraped for this part, a set of conditions is introduced to determine whether or not a book listed in the catalogue should be considered a "valid" book. The conditions are:
1. **The book must be rated at least once.** This is because we are going to look into the number of ratings as well as average ratings, and the books that lack these details already will not be helpful in further analysis.
2. **The author name must be already presented in the row.** Although this is the catalogue of Ernest Hemingway, it is noticeable that many books either included Ernest Hemingway just as "introductor" or "reviewer", meaning he was not the actual author of the book, or the book is a compilation of many artists that cannot be assigned to Hemingway only. Therefore, only if the text "Ernest Hemingway" is presented, should it be considered a book by this respectable author.


```python
urls_hemingway = []
ranks_hemingway = {}

def scrape_hemingway_books(total_pages):
    """
    Scrapes book URLs and their ranks from Goodreads' Ernest Hemingway catalogue across multiple pages.
    
    Parameters:
        total_pages (int): The total number of pages to scrape (e.g., 18 pages for this dataset).
    """
    for i in range(1, total_pages+1):
        driver.get(f"https://www.goodreads.com/author/list/1455.Ernest_Hemingway?page={i}&per_page=100")
        print(f"Scraping page {i} out of {total_pages} pages")
        time.sleep(0.7)

        # Close modal overlay pop-up if it exists
        overlay = driver.find_elements(By.CLASS_NAME, "modal--centered")
        if len(overlay) > 0:
            try:
                close_overlay_button = overlay[0].find_element(By.TAG_NAME, "button")
                close_overlay_button.click()
                time.sleep(3)
            except Exception:
                pass
                
        # Locate the main table containing the list of books
        mainBody = driver.find_element(By.CLASS_NAME, "tableList")
        rows = mainBody.find_elements(By.TAG_NAME, "tr")

        # Loop through each row to extract book's rank and URL
        for index, row in enumerate(rows):
            # Get book's ratings and author to remove invalid books
            ratings_text = row.find_element(By.CLASS_NAME, "minirating").text
            ratings = int(re.search(r"(?<=— )[\d,]+", ratings_text).group(0).replace(",", ""))
            author_name = row.find_element(By.CLASS_NAME, "authorName").text
            if "Ernest Hemingway" in author_name and ratings > 0:
                url = row.find_element(By.CLASS_NAME, "bookTitle").get_attribute("href")
                
                urls_hemingway.append(url)
                ranks_hemingway[url] = (i - 1) * 100 + index + 1

scrape_hemingway_books(18)
print(f"Number of books' URL to scrape: {len(urls_hemingway)}")
```

    Scraping page 1 out of 18 pages
    Scraping page 2 out of 18 pages
    Scraping page 3 out of 18 pages
    Scraping page 4 out of 18 pages
    Scraping page 5 out of 18 pages
    Scraping page 6 out of 18 pages
    Scraping page 7 out of 18 pages
    Scraping page 8 out of 18 pages
    Scraping page 9 out of 18 pages
    Scraping page 10 out of 18 pages
    Scraping page 11 out of 18 pages
    Scraping page 12 out of 18 pages
    Scraping page 13 out of 18 pages
    Scraping page 14 out of 18 pages
    Scraping page 15 out of 18 pages
    Scraping page 16 out of 18 pages
    Scraping page 17 out of 18 pages
    Scraping page 18 out of 18 pages
    Number of books' URL to scrape: 674


### Scrape for single book's details


```python
print("This is a long process, since we have to scrape all the individual book's URL.\nPlease wait patiently, or lower the number of pages scraped.")

books_hemingway = []

for i, url in enumerate(urls_hemingway):
    book_data = scrape_book_url(url, ranks_hemingway)
    books_hemingway.append(book_data)
    print_progress_bar(i+1, len(urls_hemingway))

print("\nDone!")
```

    This is a long process, since we have to scrape all the individual book's URL.
    Please wait patiently, or lower the number of pages scraped.
    Progress: [====================================================================================================] 100% - 674 scraped out of 674
    Done!


### Inspect and prepare data for further data analysis
Through inspection, we can see that this dataset contains information about 674 books, with details related to their rank, title, author, genre, etc.. The dataset has 11 columns, with the following key details:

- **rank**: An integer value indicating the rank of the book (non-null for all entries).
- **title**: The title of the book (non-null for all entries).
- **author**: The author of the book (6 missing values).
- **published_date**: The publication date of the book (242 missing values).
- **main_genre**: The primary genre of the book (493 missing values).
- **avg_rating**: The average rating of the book on a scale (non-null, floating-point).
- **num_ratings**: The number of ratings the book has received (non-null, floating-point).
- **pages**: The number of pages in the book (220 missing values, floating-point).
- **people_readings_(thousand)**: The number of people who have read the book, measured in thousands (365 missing values).
- **people_want_to_read(thousands)**: The number of people who want to read the book, measured in thousands (132 missing values).
- **language**: The language of the book (94 missing values).


```python
df_hemingway = pd.DataFrame(books_hemingway, columns=['rank', 'title', 'author', 'published_date', 'main_genre', 'avg_rating', 'num_ratings', 
                                  'pages', 'people_readings_(thousands)', 'people_want_to_read_(thousands)', 'language'])
df_hemingway
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rank</th>
      <th>title</th>
      <th>author</th>
      <th>published_date</th>
      <th>main_genre</th>
      <th>avg_rating</th>
      <th>num_ratings</th>
      <th>pages</th>
      <th>people_readings_(thousands)</th>
      <th>people_want_to_read_(thousands)</th>
      <th>language</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>The Old Man and the Sea</td>
      <td>Ernest Hemingway</td>
      <td>September 1, 1952</td>
      <td>Literature</td>
      <td>3.81</td>
      <td>1211016.0</td>
      <td>96.0</td>
      <td>0.04</td>
      <td>1.31</td>
      <td>English</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>The Sun Also Rises</td>
      <td>Ernest Hemingway</td>
      <td>October 22, 1926</td>
      <td>Classics</td>
      <td>3.79</td>
      <td>462373.0</td>
      <td>189.0</td>
      <td>17.10</td>
      <td>332.00</td>
      <td>English</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>A Farewell to Arms</td>
      <td>Ernest Hemingway</td>
      <td>September 1, 1929</td>
      <td>Fiction</td>
      <td>3.82</td>
      <td>333111.0</td>
      <td>293.0</td>
      <td>10.70</td>
      <td>265.00</td>
      <td>English</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>For Whom the Bell Tolls</td>
      <td>Ernest Hemingway</td>
      <td>October 1, 1940</td>
      <td>Classics</td>
      <td>3.98</td>
      <td>302558.0</td>
      <td>471.0</td>
      <td>14.10</td>
      <td>313.00</td>
      <td>English</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>A Moveable Feast</td>
      <td>Ernest Hemingway</td>
      <td>January 1, 1964</td>
      <td>Nonfiction</td>
      <td>4.02</td>
      <td>157212.0</td>
      <td>192.0</td>
      <td>7.91</td>
      <td>162.00</td>
      <td>English</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>669</th>
      <td>1101</td>
      <td>Al otro lado del río y entre los árboles</td>
      <td>Ernest Hemingway</td>
      <td>None</td>
      <td>None</td>
      <td>3.00</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Spanish; Castilian</td>
    </tr>
    <tr>
      <th>670</th>
      <td>1436</td>
      <td>Poems: Ernest Hemingway</td>
      <td>Ernest Hemingway</td>
      <td>November 24, 2024</td>
      <td>None</td>
      <td>5.00</td>
      <td>3.0</td>
      <td>73.0</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>English</td>
    </tr>
    <tr>
      <th>671</th>
      <td>1437</td>
      <td>Two Tales of Darkness: 'A Man of the World' an...</td>
      <td>Ernest Hemingway</td>
      <td>January 1, 1957</td>
      <td>None</td>
      <td>5.00</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
    </tr>
    <tr>
      <th>672</th>
      <td>1438</td>
      <td>The Sun Also Rises: A Norton Critical Edition ...</td>
      <td>Ernest Hemingway</td>
      <td>June 10, 2022</td>
      <td>None</td>
      <td>3.00</td>
      <td>1.0</td>
      <td>362.0</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>English</td>
    </tr>
    <tr>
      <th>673</th>
      <td>1439</td>
      <td>A Farewell To Amrs</td>
      <td>Ernest Hemingway</td>
      <td>January 1, 1957</td>
      <td>None</td>
      <td>3.00</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>None</td>
    </tr>
  </tbody>
</table>
<p>674 rows × 11 columns</p>
</div>




```python
df_hemingway.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 674 entries, 0 to 673
    Data columns (total 11 columns):
     #   Column                           Non-Null Count  Dtype  
    ---  ------                           --------------  -----  
     0   rank                             674 non-null    int64  
     1   title                            674 non-null    object 
     2   author                           668 non-null    object 
     3   published_date                   532 non-null    object 
     4   main_genre                       175 non-null    object 
     5   avg_rating                       668 non-null    float64
     6   num_ratings                      668 non-null    float64
     7   pages                            448 non-null    float64
     8   people_readings_(thousands)      303 non-null    float64
     9   people_want_to_read_(thousands)  536 non-null    float64
     10  language                         572 non-null    object 
    dtypes: float64(5), int64(1), object(5)
    memory usage: 58.1+ KB



```python
df_hemingway.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rank</th>
      <th>avg_rating</th>
      <th>num_ratings</th>
      <th>pages</th>
      <th>people_readings_(thousands)</th>
      <th>people_want_to_read_(thousands)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>674.000000</td>
      <td>668.000000</td>
      <td>6.680000e+02</td>
      <td>448.000000</td>
      <td>303.000000</td>
      <td>536.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>342.965875</td>
      <td>3.666527</td>
      <td>4.189287e+03</td>
      <td>346.281250</td>
      <td>0.243135</td>
      <td>2.621287</td>
    </tr>
    <tr>
      <th>std</th>
      <td>212.664523</td>
      <td>0.751192</td>
      <td>5.341527e+04</td>
      <td>417.628263</td>
      <td>1.519364</td>
      <td>23.999436</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000e+00</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>169.250000</td>
      <td>3.250000</td>
      <td>2.000000e+00</td>
      <td>106.250000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>337.500000</td>
      <td>3.770000</td>
      <td>7.000000e+00</td>
      <td>240.000000</td>
      <td>0.000000</td>
      <td>0.010000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>506.000000</td>
      <td>4.052500</td>
      <td>3.700000e+01</td>
      <td>453.250000</td>
      <td>0.010000</td>
      <td>0.050000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1439.000000</td>
      <td>5.000000</td>
      <td>1.211016e+06</td>
      <td>4489.000000</td>
      <td>17.100000</td>
      <td>332.000000</td>
    </tr>
  </tbody>
</table>
</div>



After inspection, we can deduce that the dataset contains some missing data that can affect the further calculation and analysis. The missing data can be due to the fact that the individual book's page on Goodreads does not contain the required information, or the process of scraping data meets with some network errors.

To clean the data, we will drop all the null results from the four columns: authors, avg_rating, num_ratings, since our analysis is based heavily on the ratings data, while the books without a respective author do indicate an invalid book as it makes little sense for a book without a writer.

After cleaning the data and drop the rows which contain the null results, our clean dataset now consists of 1360 books, as depicted below. The cleaned data is saved to hemingway_books.csv


```python
# Drop invalid rows
cleaned_df_hemingway = df_hemingway.dropna(subset=['author', 'avg_rating', 'num_ratings'])

# Convert the column to datetime
cleaned_df_hemingway.loc[:, 'published_date'] = pd.to_datetime(cleaned_df_hemingway['published_date'], errors='coerce')

# Ensure the column has datetime values and then extract the date part
cleaned_df_hemingway.loc[:, 'published_date'] = cleaned_df_hemingway['published_date'].apply(lambda x: x.date() if pd.notna(x) else x)

cleaned_df_hemingway.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Index: 668 entries, 0 to 673
    Data columns (total 11 columns):
     #   Column                           Non-Null Count  Dtype  
    ---  ------                           --------------  -----  
     0   rank                             668 non-null    int64  
     1   title                            668 non-null    object 
     2   author                           668 non-null    object 
     3   published_date                   530 non-null    object 
     4   main_genre                       175 non-null    object 
     5   avg_rating                       668 non-null    float64
     6   num_ratings                      668 non-null    float64
     7   pages                            448 non-null    float64
     8   people_readings_(thousands)      303 non-null    float64
     9   people_want_to_read_(thousands)  536 non-null    float64
     10  language                         572 non-null    object 
    dtypes: float64(5), int64(1), object(5)
    memory usage: 62.6+ KB



```python
# Write cleaned data to csv file
cleaned_df_hemingway.to_csv('hemingway_books.csv', index=False, encoding='utf-8')
```

### Language analysis


```python
# Create a Pandas DataFrame for all the books' data
df_hemingway_with_lang = cleaned_df_hemingway.dropna(subset=['language'])
print(f"Number of books with languages available: {df_hemingway_with_lang.shape[0]}")
print(f"Number of books in English: {df_hemingway_with_lang[df_hemingway_with_lang["language"] == "English"].shape[0]}")
```

    Number of books with languages available: 572
    Number of books in English: 292



```python
# Count books by language
books_by_language = df_hemingway_with_lang['language'].value_counts()

# Separate top 10 languages and group others
top_languages = books_by_language.head(15)

# Prepare the data for Seaborn
books_by_language_df = top_languages.reset_index()
books_by_language_df.columns = ['Language', 'Count']

# Plot a bar chart using Seaborn
plt.figure(figsize=(8, 6))
sns.barplot(data=books_by_language_df, x='Language', y='Count', edgecolor='black')
plt.title('Number of Books Published by Language, top 15', fontsize=16)
plt.xlabel('Language', fontsize=14)
plt.ylabel('Number of Books', fontsize=14)
plt.xticks(rotation=90, fontsize=12)
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()

# Display the table and the bar chart
plt.show()
```


    
![png](output_45_0.png)
    


The bar chart illustrates the number of books published in the top 15 languages. Overall, English dominates as the most significant language for book publications, while other languages lag far behind in comparison.

As depicted, English leads with a striking figure of nearly 300 books, which far exceeds the number published in any other language. This highlights its role as the most prominent language for literature or publications globally.

In contrast, Spanish (Castilian), the second-most prominent language, accounts for only around 40 books, representing a significant gap from English. Other languages, such as Russian and Italian, follow closely with slightly fewer than 40 books each. Meanwhile, German and Chinese have relatively moderate figures, hovering between 20 and 30 publications. Languages like Portuguese, French, Arabic, and Dutch each contribute a smaller number, approximately 10–15 books. Lastly, Vietnamese, Turkish, and Modern Greek round out the list with the lowest figures, each registering fewer than 10 books.



### Author's age analysis

In this part, the author's age relationship between **the average page counts**, as well as **the average ratings** will be examined. 


```python
from dateutil.relativedelta import relativedelta

# Define Ernest Hemingway's birth and death dates in datetime format
birth_date = pd.to_datetime("1899-07-21").date()
death_date = pd.to_datetime("1961-07-02").date()

# Filter the dataframe to include only books published between birth and death dates
df_hemingway_with_date = cleaned_df_hemingway.dropna(subset=['published_date'])
df_hemingway_with_date = df_hemingway_with_date[(df_hemingway_with_date['published_date'] >= birth_date) & (df_hemingway_with_date['published_date'] <= death_date)]

def group_data_by_age(df, column, new_col_name):
    """
    Groups the data by the author's age at publication and calculates the mean of the specified column.

    Parameters:
    - df: The DataFrame containing the book data.
    - column: The column name (string) for which to calculate the mean (e.g., 'pages').
    - new_col_name: The name for the new column in the grouped DataFrame (e.g., 'average_page_count').

    Returns:
    - A new DataFrame grouped by age_at_publication, with the mean of the specified column.
    """
    df_drop_null = df.dropna(subset=[column])
    print(f"Number of books with appropriate dates: {df_drop_null.shape[0]}")
    df_drop_null = df_drop_null.copy()
    df_drop_null.loc[:, 'age_at_publication'] = df_drop_null['published_date'].apply(lambda x: relativedelta(x, birth_date).years)

    df_group = df_drop_null.groupby('age_at_publication').agg({column: 'mean'}).reset_index()
    df_group.columns = ['age_at_publication', new_col_name]

    return df_group

df_hemingway_with_date_and_page = group_data_by_age(df_hemingway_with_date, 'pages', 'average_page_count')
df_hemingway_with_date_and_page
```

    Number of books with appropriate dates: 79





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age_at_publication</th>
      <th>average_page_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>22</td>
      <td>380.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>23</td>
      <td>19.000000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>24</td>
      <td>45.200000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>25</td>
      <td>47.500000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>26</td>
      <td>200.000000</td>
    </tr>
    <tr>
      <th>5</th>
      <td>27</td>
      <td>60.727273</td>
    </tr>
    <tr>
      <th>6</th>
      <td>28</td>
      <td>69.000000</td>
    </tr>
    <tr>
      <th>7</th>
      <td>29</td>
      <td>322.500000</td>
    </tr>
    <tr>
      <th>8</th>
      <td>30</td>
      <td>293.000000</td>
    </tr>
    <tr>
      <th>9</th>
      <td>32</td>
      <td>274.000000</td>
    </tr>
    <tr>
      <th>10</th>
      <td>33</td>
      <td>52.777778</td>
    </tr>
    <tr>
      <th>11</th>
      <td>34</td>
      <td>87.000000</td>
    </tr>
    <tr>
      <th>12</th>
      <td>36</td>
      <td>104.166667</td>
    </tr>
    <tr>
      <th>13</th>
      <td>37</td>
      <td>176.000000</td>
    </tr>
    <tr>
      <th>14</th>
      <td>38</td>
      <td>254.750000</td>
    </tr>
    <tr>
      <th>15</th>
      <td>39</td>
      <td>344.000000</td>
    </tr>
    <tr>
      <th>16</th>
      <td>41</td>
      <td>322.000000</td>
    </tr>
    <tr>
      <th>17</th>
      <td>42</td>
      <td>1072.000000</td>
    </tr>
    <tr>
      <th>18</th>
      <td>44</td>
      <td>642.000000</td>
    </tr>
    <tr>
      <th>19</th>
      <td>47</td>
      <td>507.000000</td>
    </tr>
    <tr>
      <th>20</th>
      <td>50</td>
      <td>344.000000</td>
    </tr>
    <tr>
      <th>21</th>
      <td>52</td>
      <td>250.250000</td>
    </tr>
    <tr>
      <th>22</th>
      <td>53</td>
      <td>374.000000</td>
    </tr>
    <tr>
      <th>23</th>
      <td>54</td>
      <td>528.000000</td>
    </tr>
    <tr>
      <th>24</th>
      <td>55</td>
      <td>123.000000</td>
    </tr>
    <tr>
      <th>25</th>
      <td>56</td>
      <td>191.000000</td>
    </tr>
    <tr>
      <th>26</th>
      <td>57</td>
      <td>277.000000</td>
    </tr>
    <tr>
      <th>27</th>
      <td>60</td>
      <td>339.000000</td>
    </tr>
    <tr>
      <th>28</th>
      <td>61</td>
      <td>117.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Plotting age vs page count
plt.figure(figsize=(10, 6))
sns.lineplot(data=df_hemingway_with_date_and_page, x='age_at_publication', y='average_page_count', marker='o', color='b')

# Adding labels and title
plt.title('Author\'s Age at Publication vs Page Count', fontsize=14)
plt.xlabel('Author\'s Age at Publication', fontsize=12)
plt.ylabel('Page Count', fontsize=12)

# Display plot
plt.grid(True)
plt.show()
```


    
![png](output_49_0.png)
    


The line chart illustrates the relationship between the Ernest Hemingway's age at publication and the page count of their books. Overall, the page count fluctuates significantly, but there is a particularly productive span between ages 40 and 54, where he produced their longest and most consistent works.

At the beginning of the timeline, between ages 22 and 35, the page count is highly irregular. At age 22, there was an initial peak of nearly 380 pages, followed by a sharp drop to near zero at age 23. The page count then oscillates between 50 and 200 pages, with a modest rise when he was 29 (around 320 pages) before falling again to low values at ages 32 and 33.

In his midlife years, Hemingway began a period of gradual growth in productivity, especially in between ages 40 and 54, when his page count reached its most significant and consistent levels. At his 40s, the page count was around 350 pages, and it climbed dramatically to over 1,000 pages at age 43, marking the highest point on the chart. Although the page count decreases after this peak, it remains substantial, with around 650 pages at age 44, but then witnessed a gradual decline in the following years. This period of decline also coincides with the gradual increase of Hemingway's mental problems in real life.


```python
df_hemingway_with_date_english = df_hemingway_with_date[df_hemingway_with_date["language"] == "English"]
df_hemingway_with_date_non_english = df_hemingway_with_date[df_hemingway_with_date["language"] != "English"]

df_hemingway_with_date_and_ratings_english = group_data_by_age(df_hemingway_with_date_english, 'avg_rating', 'average_ratings')
df_hemingway_with_date_and_ratings_non_english = group_data_by_age(df_hemingway_with_date_non_english, 'avg_rating', 'average_ratings')
```

    Number of books with appropriate dates: 64
    Number of books with appropriate dates: 46



```python
# Plotting age vs page count
plt.figure(figsize=(10, 6))
sns.lineplot(data=df_hemingway_with_date_and_ratings_english, x='age_at_publication', y='average_ratings', marker='o', color='b')
sns.regplot(data=df_hemingway_with_date_and_ratings_english, x='age_at_publication', y='average_ratings', scatter=False, color='red', line_kws={'color': 'red', 'linewidth': 2})

# Adding labels and title
plt.title('Author\'s Age at Publication vs Average Ratings (English books)', fontsize=14)
plt.xlabel('Author\'s Age at Publication', fontsize=12)
plt.ylabel('Average Ratings', fontsize=12)

# Display plot
plt.grid(True)
plt.show()
```


    
![png](output_52_0.png)
    



```python
# Plotting age vs page count
plt.figure(figsize=(10, 6))
sns.lineplot(data=df_hemingway_with_date_and_ratings_non_english, x='age_at_publication', y='average_ratings', marker='o', color='b')
sns.regplot(data=df_hemingway_with_date_and_ratings_non_english, x='age_at_publication', y='average_ratings', scatter=False, color='red', line_kws={'color': 'red', 'linewidth': 2})

# Adding labels and title
plt.title('Author\'s Age at Publication vs Average Ratings (Non-English books)', fontsize=14)
plt.xlabel('Author\'s Age at Publication', fontsize=12)
plt.ylabel('Average Ratings', fontsize=12)

# Display plot
plt.grid(True)
plt.show()
```


    
![png](output_53_0.png)
    


The two charts provided show the relationship between the Hemingway's age at the time of publication and the average ratings of his books, both in English and non-English languages. 

For English books, the data reveals an inverse relationship between the his age and the average ratings of the books published at that age. As he got older, the average ratings tend to increase, albeit with some fluctuations. The highest average rating is observed around the author's age of 40-45, as already analysed that it was his most productive era. 

The relationship between the Hemingway's age at publication and the average ratings of their non-English books is more complex. There is a general upward trend in the average ratings in correlation to him getting older, with some notable peaks and drops. The highest average rating is observed around the author's age of 45-50 similarly, while it is noticeable that the ratings for non-English books at the final stages of Hemingway's life both saw a sharp decline.

All in all, although there were some differences in the fluctuations between Hemingway's English and non-English cataglogue, it is it is clear that his works gained more admiration as he grew older, and there is a global consensus on the appreciation of his work.

### Relationship between pages and average ratings

The check for outliers for the number of pages and the average rating is performed similarly to the previous task


```python
cleaned_df_hemingway.dropna(subset=['pages', 'avg_rating'])

fig, axes = plt.subplots(1, 2, figsize=(15, 6), sharey=True)

# First boxplot
sns.boxplot(x=cleaned_df_hemingway['avg_rating'], ax=axes[0])
axes[0].set_title('Boxplot of Average Ratings')
axes[0].set_xlabel('Average Ratings')

# Second boxplot
sns.boxplot(x=cleaned_df_hemingway['pages'], ax=axes[1])
axes[1].set_title('Boxplot of Pages')
axes[1].set_xlabel('Pages')

plt.tight_layout()
plt.show()
```


    
![png](output_56_0.png)
    



```python
df_hemingway_drop_outliers_ratings_pages = drop_outliers(cleaned_df_hemingway, ['avg_rating', 'pages'])

print(f"Original data size: {cleaned_df_hemingway.shape[0]}")
print(f"Data size after outlier removal: {df_hemingway_drop_outliers_ratings_pages.shape[0]}")
```

    Original data size: 668
    Data size after outlier removal: 415



```python
plt.figure(figsize=(10, 6))
sns.regplot(
    x='pages', 
    y='avg_rating', 
    data=df_hemingway_drop_outliers_ratings_pages, 
    scatter_kws={'alpha': 0.5, 'color': 'blue'}, 
    line_kws={'color': 'red'}
)

# Add labels and title
plt.xlabel('Pages')
plt.ylabel('Average Ratings')
plt.title('Relationship Between Pages and Average Rating (Without Outliers)')
plt.grid(True)

# Show plot
plt.show()
```


    
![png](output_58_0.png)
    


The chart shows the relationship between the number of pages in a book and the average rating of the book, and could potentially be used to analyze the writing patterns and audience reception of Ernest Hemingway. The chart displays a positive linear relationship between the number of pages and the average rating of Hemingway's books. As the number of pages increases, the average rating tends to rise, suggesting that Hemingway's longer works may have been better received by readers.

While the overall trend is positive, there is significant variation in the average ratings, even for books with similar page counts. This suggests that factors other than just the length of the book, such as the content, writing style, and critical reception, also played a role in determining the average ratings of Hemingway's works.

The chart shows a few data points that stand out as potential safe outliers, with either exceptionally high or low average ratings compared to the general trend. These could represent Hemingway's most well-received or lesser-known works, and would be worth further investigation in the future.

### Current interests in the books

This part inspects the interests in Hemingway's catalogue by looking into the relationship between the number of current people reading his works and both the number of ratings and the average ratings. In this part, it should be noted that outliers **will be taken into account**, due to the fact that there are too few people who are currently reading his works, so the introduction of outliers for the books that have more people interested will be worth investigating.


```python
plt.figure(figsize=(10, 6))
sns.regplot(
    x='people_readings_(thousands)', 
    y='num_ratings', 
    data=cleaned_df_hemingway, 
    scatter_kws={'alpha': 0.5, 'color': 'blue'}, 
    line_kws={'color': 'red'}
)

plt.xlabel('Number of people currently reading')
plt.ylabel('Number of ratings')
plt.title('Relationship Between People Currently Reading and Number of Ratings')
plt.grid(True)

plt.show()
```


    
![png](output_61_0.png)
    



```python
plt.figure(figsize=(10, 6))
sns.regplot(
    x='people_readings_(thousands)', 
    y='avg_rating', 
    data=cleaned_df_hemingway, 
    scatter_kws={'alpha': 0.5, 'color': 'blue'}, 
    line_kws={'color': 'red'}
)

# Add labels and title
plt.xlabel('Number of people currently reading')
plt.ylabel('Number of ratings')
plt.title('Relationship Between People Currently Reading and Number of Ratings')
plt.grid(True)

# Show plot
plt.show()
```


    
![png](output_62_0.png)
    


Both charts show a positive linear relationship between the number of people currently reading and the number of ratings, as well as the average ratings. As the number of people currently reading increases, the number of ratings and the average ratings tend to rise as well. The charts contain a few outliers, which are data points that deviate significantly from the general trend. In the first chart, the outlier at around 15 people currently reading shows a higher number of ratings compared to the trend. In the second chart, the outlier at around 15 people currently reading also exhibits a higher average rating compared to the trend.

The outliers in the data could represent Hemingway's most popular or critically acclaimed works, which have attracted a relatively small but highly engaged readership. These outliers may also indicate that certain Hemingway books have resonated strongly with a dedicated group of readers, leading to a disproportionately high number of ratings and average ratings compared to the general trend.


```python

```
